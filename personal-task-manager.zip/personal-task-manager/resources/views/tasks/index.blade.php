<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal Task Manager</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-8">
    <div class="max-w-4xl mx-auto bg-white p-6 rounded-lg shadow-md">
        <h1 class="text-2xl font-bold mb-6 text-gray-800">Personal Task Manager</h1>

        @if(session('success'))
            <div class="bg-green-100 text-green-700 p-3 rounded mb-4">
                {{ session('success') }}
            </div>
        @endif

        <!-- Add Task Form -->
        <form action="{{ route('tasks.store') }}" method="POST" class="mb-8 border-b pb-6">
            @csrf
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <input type="text" name="task_name" placeholder="Task Name *" required class="border p-2 rounded w-full">
                <input type="date" name="due_date" class="border p-2 rounded w-full">
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Add Task</button>
            </div>
            <textarea name="description" placeholder="Description (Optional)" class="border p-2 rounded w-full h-20"></textarea>
        </form>

        <!-- View Tasks List -->
        <h2 class="text-xl font-semibold mb-4 text-gray-700">Your Tasks</h2>
        <div class="space-y-4">
            @forelse($tasks as $task)
                <div class="flex items-center justify-between border p-4 rounded-lg bg-gray-50">
                    <div class="flex-1">
                        <div class="flex items-center gap-2">
                            <h3 class="font-bold text-lg {{ $task->status === 'Completed' ? 'line-through text-gray-400' : 'text-gray-800' }}">
                                {{ $task->task_name }}
                            </h3>
                            <span class="text-xs px-2 py-1 rounded {{ $task->status === 'Completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800' }}">
                                {{ $task->status }}
                            </span>
                        </div>
                        @if($task->description)
                            <p class="text-gray-600 text-sm mt-1">{{ $task->description }}</p>
                        @endif
                        @if($task->due_date)
                            <p class="text-gray-400 text-xs mt-1">Due: {{ $task->due_date }}</p>
                        @endif
                    </div>

                    <div class="flex items-center gap-2">
                        <!-- Update Status Toggle -->
                        <form action="{{ route('tasks.toggleStatus', $task) }}" method="POST">
                            @csrf
                            @method('PATCH')
                            <button type="submit" class="text-xs px-3 py-1 border rounded text-gray-700 hover:bg-gray-200">
                                {{ $task->status === 'Pending' ? 'Mark Completed' : 'Mark Pending' }}
                            </button>
                        </form>

                        <!-- Edit Task -->
                        <a href="{{ route('tasks.edit', $task) }}" class="text-xs bg-indigo-500 text-white px-3 py-1 rounded hover:bg-indigo-600">Edit</a>

                        <!-- Delete Task -->
                        <form action="{{ route('tasks.destroy', $task) }}" method="POST" onsubmit="return confirm('Delete this task?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="text-xs bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600">Delete</button>
                        </form>
                    </div>
                </div>
            @empty
                <p class="text-gray-500 text-center py-4">No tasks found. Add your first task above!</p>
            @endforelse
        </div>
    </div>
</body>
</html>