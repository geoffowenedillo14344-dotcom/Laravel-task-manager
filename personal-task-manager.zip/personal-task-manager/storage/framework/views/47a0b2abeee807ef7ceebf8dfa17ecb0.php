<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal Task Manager</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-8">
    <div class="max-w-4xl mx-auto bg-white p-6 rounded-lg shadow-md">
        <h1 class="text-2xl font-bold mb-6 text-gray-800">Personal Task Manager</h1>

        <?php if(session('success')): ?>
            <div class="bg-green-100 text-green-700 p-3 rounded mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Add Task Form -->
        <form action="<?php echo e(route('tasks.store')); ?>" method="POST" class="mb-8 border-b pb-6">
            <?php echo csrf_field(); ?>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <input type="text" name="task_name" placeholder="Task Name *" required class="border p-2 rounded w-full">
                <input type="date" name="due_date" class="border p-2 rounded w-full">
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Add Task</button>
            </div>
            <textarea name="description" placeholder="Description (Optional)" class="border p-2 rounded w-full h-20"></textarea>
        </form>

        <!-- View Tasks List -->
        <h2 class="text-xl font-semibold mb-4 text-gray-700">Your Tasks</h2>
        <div class="space-y-4">
            <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex items-center justify-between border p-4 rounded-lg bg-gray-50">
                    <div class="flex-1">
                        <div class="flex items-center gap-2">
                            <h3 class="font-bold text-lg <?php echo e($task->status === 'Completed' ? 'line-through text-gray-400' : 'text-gray-800'); ?>">
                                <?php echo e($task->task_name); ?>

                            </h3>
                            <span class="text-xs px-2 py-1 rounded <?php echo e($task->status === 'Completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'); ?>">
                                <?php echo e($task->status); ?>

                            </span>
                        </div>
                        <?php if($task->description): ?>
                            <p class="text-gray-600 text-sm mt-1"><?php echo e($task->description); ?></p>
                        <?php endif; ?>
                        <?php if($task->due_date): ?>
                            <p class="text-gray-400 text-xs mt-1">Due: <?php echo e($task->due_date); ?></p>
                        <?php endif; ?>
                    </div>

                    <div class="flex items-center gap-2">
                        <!-- Update Status Toggle -->
                        <form action="<?php echo e(route('tasks.toggleStatus', $task)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button type="submit" class="text-xs px-3 py-1 border rounded text-gray-700 hover:bg-gray-200">
                                <?php echo e($task->status === 'Pending' ? 'Mark Completed' : 'Mark Pending'); ?>

                            </button>
                        </form>

                        <!-- Edit Task -->
                        <a href="<?php echo e(route('tasks.edit', $task)); ?>" class="text-xs bg-indigo-500 text-white px-3 py-1 rounded hover:bg-indigo-600">Edit</a>

                        <!-- Delete Task -->
                        <form action="<?php echo e(route('tasks.destroy', $task)); ?>" method="POST" onsubmit="return confirm('Delete this task?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-xs bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600">Delete</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-gray-500 text-center py-4">No tasks found. Add your first task above!</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html><?php /**PATH /workspaces/Laravel-task-manager/personal-task-manager/resources/views/tasks/index.blade.php ENDPATH**/ ?>